﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace DoorManagement.Service.Models
{
    [DataContract]
    public class Door
    {

        private Guid id;

        private string doorName;

        private bool isClosed;

        private bool islocked;

        private bool removeDoor;

        [DataMember]
        public bool IsLocked
        {
            get { return islocked; }
            set { islocked = value; }
        }

        [DataMember]
        public bool IsClosed
        {
            get { return isClosed; }
            set { isClosed = value; }
        }

        [DataMember]
        public string DoorName
        {
            get { return doorName; }
            set { doorName = value; }
        }

        [DataMember]
        public Guid Id
        {
            get { return id; }
            set { id = value; }
        }

        [DataMember]
        public bool RemoveDoor
        {
            get { return removeDoor; }
            set { removeDoor = value; }
        }

    }
}
