﻿using DoorManagement.Service.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoorManagement.Service.Provider
{
    public interface IDataProvider
    {
        List<Door> GetAllDoors();

        void UpdateDoor(Door door);

        void AddNewDoor(Door newDoor);

        void RemoveExistingDoor(ObservableCollection<Door> removedDoors);

        void UpdateDoorStatus(Door door);
    }
}
