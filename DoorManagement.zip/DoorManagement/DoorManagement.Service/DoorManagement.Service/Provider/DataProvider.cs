﻿using DoorManagement.ORM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessModel = DoorManagement.Service.Models;
 

namespace DoorManagement.Service.Provider
{
    public class DataProvider : IDataProvider
    {
        public void AddNewDoor(BusinessModel.Door newDoor)
        {
            var db = new DoorManagerEntities();
            db.Doors.Add(new ORM.Door
            {
                Id = newDoor.Id,
                DoorName = newDoor.DoorName,
                IsClosed = newDoor.IsClosed,
                IsLocked = newDoor.IsLocked
            });

            db.SaveChanges();
            }

        public List<BusinessModel.Door> GetAllDoors()
        {
            var allDoors = new List<BusinessModel.Door>();
            DoorManagerEntities db = new DoorManagerEntities();
            foreach (var door in db.Doors)
            {
                allDoors.Add(new BusinessModel.Door
                {
                    Id = door.Id,
                    DoorName = door.DoorName,
                    IsClosed = door.IsClosed,
                    IsLocked = door.IsLocked
                });
            }

            return allDoors;
        }

        public void RemoveExistingDoor(ObservableCollection<BusinessModel.Door> removedDoors)
        {
            var db = new DoorManagerEntities();
            foreach (var door in removedDoors)
            {
                if (db.Doors.Any(d => d.Id == door.Id))
                {
                    var doorToRemove = db.Doors.FirstOrDefault(d => d.Id == door.Id);
                    db.Doors.Remove(doorToRemove);
                    db.SaveChanges();
                }
            }
        }

        public void UpdateDoor(BusinessModel.Door door)
        {
            var db = new DoorManagerEntities();
            var existingDoor = db.Doors.FirstOrDefault(d => d.Id == door.Id);
            if (existingDoor != null)
            {
                existingDoor.DoorName = door.DoorName;
                existingDoor.IsClosed = door.IsClosed;
                existingDoor.IsLocked = door.IsLocked;
                db.SaveChanges();
            }
        }

        public void UpdateDoorStatus(BusinessModel.Door door)
        {
            var db = new DoorManagerEntities();
            var existingDoor = db.Doors.FirstOrDefault(d => d.Id == door.Id);
            if (existingDoor != null)
            {
                existingDoor.IsClosed = door.IsClosed;
                existingDoor.IsLocked = door.IsLocked;
                db.SaveChanges();
            }
        }
    }
}
