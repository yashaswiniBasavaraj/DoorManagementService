﻿using DoorManagement.Service.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace DoorManagement.Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IIDoorManagementService" in both code and config file together.
    [ServiceContract]
    public interface IDoorManagementService
    {
        [OperationContract]
        List<Door> GetAllDoors();

        [OperationContract]
        void UpdateDoor(Door door);

        [OperationContract]
        void AddNewDoor(Door newDoor);

        [OperationContract]
        void RemoveExistingDoor(ObservableCollection<Door> removedDoors);

        [OperationContract]
        void UpdateDoorStatus(Door door);

    }
}
