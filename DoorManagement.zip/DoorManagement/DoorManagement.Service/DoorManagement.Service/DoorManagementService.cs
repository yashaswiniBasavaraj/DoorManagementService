﻿using DoorManagement.ORM;
using DoorManagement.Service.Provider;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using BusinessModel = DoorManagement.Service.Models;


namespace DoorManagement.Service
{
    public class DoorManagementService : IDoorManagementService
    {
        public DoorManagementService()
        {
            this.Provider = new DataProvider();
        }
        public IDataProvider Provider { get; set; }

        /// <summary>
        /// Service method to add new door record
        /// </summary>
        /// <param name="newDoor">A neww door to add</param>
        public void AddNewDoor(BusinessModel.Door newDoor)
        {
            this.Provider.AddNewDoor(newDoor);
        }

        /// <summary>
        /// Service method to get all the doors recors
        /// </summary>
        /// <returns>A list of registered doors</returns>
        public List<BusinessModel.Door> GetAllDoors()
        {
            var allDoors = this.Provider.GetAllDoors();
            return allDoors;
        }

        /// <summary>
        /// Service method to remove existing door
        /// </summary>
        /// <param name="removedDoors"></param>
        public void RemoveExistingDoor(ObservableCollection<BusinessModel.Door> removedDoors)
        {
            this.Provider.RemoveExistingDoor(removedDoors);
        }


        /// <summary>
        /// Service method to update Existing door
        /// </summary>
        /// <param name="door"></param>
        public void UpdateDoor(BusinessModel.Door door)
        {
            this.Provider.UpdateDoor(door);
        }

        /// <summary>
        /// Service methos to update Door status
        /// </summary>
        /// <param name="door"></param>
        public void UpdateDoorStatus(BusinessModel.Door door)
        {
            this.Provider.UpdateDoorStatus(door);
        }
    }
}
