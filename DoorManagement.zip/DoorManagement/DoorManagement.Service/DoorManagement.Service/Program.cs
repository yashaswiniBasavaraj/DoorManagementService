﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace DoorManagement.Service
{
    public class Program
    {
        public static void Main(string[] args)
        {
            ServiceHost serviceHost = null;

            try 
            {
                serviceHost = new ServiceHost(typeof(DoorManagement.Service.DoorManagementService));
                serviceHost.Open();
                var serviceAddress = "http://localhost:8733/DoorManagementService";
                Console.WriteLine("The door management service has started at {0}.\n", serviceAddress);
                Console.ReadLine();
            }
            finally
            {
                if(serviceHost != null)
                {
                    serviceHost.Close();
                }
            }
        }
    }
}
