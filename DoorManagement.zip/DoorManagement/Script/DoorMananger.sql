-- A new database to manage doors in the facility
USE [master]
GO

CREATE DATABASE DoorManager

-- Creating a NEw tablle for storing Door records
Use [DoorManager]
GO

CREATE TABLE [dbo].[Door](
	[Id] [UNIQUEIDENTIFIER] PRIMARY KEY default NEWID(),
	[DoorName] nvarchar(max) NOT NULL,
	[IsClosed] bit NOT NULL,
	[IsLocked] bit NOT NULL)

-- Inserting initial values for door table
USE [DoorManager]
GO

INSERT INTO [dbo].[Door]([DoorName],[IsClosed],[IsLocked])
     VALUES('Front Door',1,1)
INSERT INTO [dbo].[Door]([DoorName],[IsClosed],[IsLocked])
     VALUES('Back Door',0,0)
INSERT INTO [dbo].[Door]([DoorName],[IsClosed],[IsLocked])
     VALUES('Admin Door',1,0)
GO