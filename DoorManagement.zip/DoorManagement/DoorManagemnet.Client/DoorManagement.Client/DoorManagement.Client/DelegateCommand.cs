﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace DoorManagement.Client
{
    public class DelegateCommand : ICommand
    {
        public DelegateCommand(Action<object> executeMethod, Predicate<object> canExecuteMethod)
        {
            this.ExecuteMethod = executeMethod;
            this.CanExecuteMethod = canExecuteMethod;
        }

        public DelegateCommand(Action<object> executeMethod) : this(executeMethod, e => { return true; })
        {
        }

        public Action<object> ExecuteMethod { get; set; }

        public Predicate<object> CanExecuteMethod { get; set; }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return this.CanExecuteMethod(parameter);
        }

        public void Execute(object parameter)
        {
            this.ExecuteMethod(parameter);
        }
    }
}
