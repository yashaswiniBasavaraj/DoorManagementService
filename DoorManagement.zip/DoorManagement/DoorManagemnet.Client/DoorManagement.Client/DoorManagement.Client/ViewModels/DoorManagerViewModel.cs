﻿using DoorManagement.Client.DoorManagementService;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace DoorManagement.Client.ViewModels
{
    public class DoorManagerViewModel : BaseViewModel,INotifyPropertyChanged
    {
        private ObservableCollection<Door> doors;

        private Door currentDoor;

        public event PropertyChangedEventHandler PropertyChanged;

        private  readonly DoorManagementServiceClient client;

        private string finalMessage;

        public DoorManagerViewModel()
        {
            client = new DoorManagementServiceClient();
            this.Doors = new ObservableCollection<Door>(client.GetAllDoors());
            this.IsModified = false;
        }

        public Door CurrentDoor
        {
            get
            {
                return this.currentDoor;
            }
            set
            {
                this.currentDoor = value;
                this.Notify(nameof(this.CurrentDoor));
            }
        }

        public String FinalMessage
        {
            get
            {
                return this.finalMessage;
            }
            set
            {
                this.finalMessage = value;
                this.Notify(nameof(this.FinalMessage));
            }
        }

        public ObservableCollection<Door> Doors
        {
            get
            {
                return this.doors;
            }
            set
            {
                this.doors = value;
                this.Notify(nameof(this.Doors));
            }
        }

        public ICommand AddDoorCommand
        {
            get
            {
                return new DelegateCommand(this.AddNewDoor);
            }
        }

        public ICommand RemoveDoorCommand
        {
            get
            {
                return new DelegateCommand(this.RemoveExistingDoors);
            }
        }

        public bool IsModified
        {
            get;
            set;
                
        }

        public ICommand SaveDoorCommand
        {
            get
            {
                return new DelegateCommand(this.SaveDoor);
            }
        }

        private void AddNewDoor(object parameter)
        {
            this.IsModified = false;
            this.Notify(nameof(this.IsModified));
            var door = new Door
            {
                Id = Guid.NewGuid(),
                DoorName = String.Empty,
                IsClosed = false
            };
            this.Doors.Add(door);
            this.CurrentDoor = door;
        }

        private void SaveDoor(object parameter)
        {
            var existingDoors = client.GetAllDoors();
            if(existingDoors.Any(d => d.Id == CurrentDoor.Id))
            {
                var isModified = existingDoors.Any(d => d.Id == CurrentDoor.Id && (d.DoorName != CurrentDoor.DoorName || d.IsClosed != CurrentDoor.IsClosed || d.IsLocked != CurrentDoor.IsLocked));
                if (isModified)
                {
                    client.UpdateDoor(this.CurrentDoor);
                    this.FinalMessage = "Door record updated successfully";
                }
                else
                {
                    this.FinalMessage = "The record is up-to-date. Hence nothing to update";
                }
            }
            else
            {
                client.AddNewDoor(this.CurrentDoor);
                this.FinalMessage = "A new Door Record is successfully added";
            }

            this.IsModified = true;
            this.Notify(nameof(this.IsModified));
        }

        private void RemoveExistingDoors(object parameter)
        {
            this.IsModified = false;
            this.Notify(nameof(this.IsModified));
            var removeDoors = this.Doors.Where(d => d.RemoveDoor).ToArray();
            client.RemoveExistingDoor(removeDoors);
            this.Doors = new ObservableCollection<Door>(client.GetAllDoors());
        }

        private void Notify(string property)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }
}
