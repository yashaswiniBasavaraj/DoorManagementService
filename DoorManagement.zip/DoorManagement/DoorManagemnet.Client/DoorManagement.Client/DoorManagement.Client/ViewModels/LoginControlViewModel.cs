﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace DoorManagement.Client.ViewModels
{
    public class LoginControlViewModel : BaseViewModel
    {

        public ICommand ProceedCommand => new DelegateCommand(this.ProceedToManageDoors);

        private void ProceedToManageDoors(object parameter)
        {
            NavigationCommands.BrowseBack.InputGestures.Clear();
            DoorManager doorView = new DoorManager();
            if(this.MainPage != null)
            {
                this.MainPage.frmNavigation.Navigate(doorView);
            }
        }
    }
}
