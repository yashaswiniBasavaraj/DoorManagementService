﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace DoorManagement.Client.ViewModels
{
    public class BaseViewModel
    {
        private Main mainPage;
        public Main MainPage
        {
            get
            {
                if (this.mainPage == null)
                {
                    this.mainPage = Application.Current.Windows.OfType<Main>().FirstOrDefault();
                }

                return this.mainPage;
            }
        }
    }
}
