﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoorManagement.Client.Model
{
    public class Door
    {

        public bool IsLocked
        {
            get; 
            set;
        }

        public bool IsClosed
        {
            get;
            set;
        }

        public string DoorName
        {
            get;
            set;
        }

        public Guid Id
        {
            get;
            set;
        }

        public bool RemoveDoor
        {
            get;
            set;
        }
    }
}
