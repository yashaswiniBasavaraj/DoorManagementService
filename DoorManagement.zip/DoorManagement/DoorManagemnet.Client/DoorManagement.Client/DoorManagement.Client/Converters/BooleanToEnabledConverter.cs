﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace DoorManagement.Client.Converters
{
    public class BooleanToEnabledConverter : DependencyObject, IValueConverter
    {
        public static readonly DependencyProperty InvertProperty = DependencyProperty.Register(
            "Invert", typeof(bool), typeof(BooleanToEnabledConverter), new PropertyMetadata(default(bool)));

        public bool Invert
        {
            get { return (bool)GetValue(InvertProperty); }
            set { SetValue(InvertProperty, value); }
        }
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var currentValue = (bool?)value;
            bool finalValue = true;
            switch (currentValue)
            {
                case true:
                    finalValue = Invert;
                    break;
                case false:
                    finalValue = !Invert;
                    break;
                case null:
                    break;
            }

            return finalValue;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
